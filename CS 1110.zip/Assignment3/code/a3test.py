"""
Unit Test for Assignment A3

This module implements several test cases for a3.

Jackson Bauer (jhb338) and Hermogenes Parente (hp298)
10/3/18
"""
import introcs
import a3


def test_complement():
    """
    Test function complement
    """
    introcs.assert_equals(introcs.RGB(255-250, 255-0, 255-71),
                          a3.complement_rgb(introcs.RGB(250, 0, 71)))
    introcs.assert_equals(introcs.RGB(255-255, 255-0, 255-0),
                          a3.complement_rgb(introcs.RGB(255, 0, 0)))


def test_round():
    """
    Test function round (a3 version)
    """
    introcs.assert_equals(130.6,   a3.round(130.59,1))
    introcs.assert_equals(130.5,   a3.round(130.54,1))
    introcs.assert_equals(100.0,   a3.round(100,1))
    introcs.assert_equals(100.6,   a3.round(100.55,1))
    introcs.assert_equals(99.57,   a3.round(99.566,2))
    introcs.assert_equals(99.99,   a3.round(99.99,2))
    introcs.assert_equals(100.00,  a3.round(99.995,2))
    introcs.assert_equals(22.00,   a3.round(21.99575,2))
    introcs.assert_equals(21.99,   a3.round(21.994,2))
    introcs.assert_equals(10.01,   a3.round(10.013567,2))
    introcs.assert_equals(10.00,   a3.round(10.000000005,2))
    introcs.assert_equals(10.00,   a3.round(9.9999,3))
    introcs.assert_equals(9.999,   a3.round(9.9993,3))
    introcs.assert_equals(1.355,   a3.round(1.3546,3))
    introcs.assert_equals(1.354,   a3.round(1.3544,3))
    introcs.assert_equals(0.046,   a3.round(.0456,3))
    introcs.assert_equals(0.045,   a3.round(.0453,3))
    introcs.assert_equals(0.006,   a3.round(.0056,3))
    introcs.assert_equals(0.001,   a3.round(.0013,3))
    introcs.assert_equals(0.000,   a3.round(.0004,3))
    introcs.assert_equals(0.001,   a3.round(.0009999,3))
    introcs.assert_equals(100,   a3.round(99.5,0))
    introcs.assert_equals(99,   a3.round(99.4,0))



def test_str5():
    """
    Test function str5
    """
    introcs.assert_equals('130.6',  a3.str5(130.59))
    introcs.assert_equals('130.5',  a3.str5(130.54))
    introcs.assert_equals('100.0',  a3.str5(100))
    introcs.assert_equals('100.6',  a3.str5(100.55))
    introcs.assert_equals('99.57',  a3.str5(99.566))
    introcs.assert_equals('99.99',  a3.str5(99.99))
    introcs.assert_equals('100.0',  a3.str5(99.995))
    introcs.assert_equals('22.00',  a3.str5(21.99575))
    introcs.assert_equals('21.99',  a3.str5(21.994))
    introcs.assert_equals('10.01',  a3.str5(10.013567))
    introcs.assert_equals('10.00',  a3.str5(10.000000005))
    introcs.assert_equals('10.00',  a3.str5(9.9999))
    introcs.assert_equals('9.999',  a3.str5(9.9993))
    introcs.assert_equals('1.355',  a3.str5(1.3546))
    introcs.assert_equals('1.354',  a3.str5(1.3544))
    introcs.assert_equals('0.046',  a3.str5(.0456))
    introcs.assert_equals('0.045',  a3.str5(.0453))
    introcs.assert_equals('0.006',  a3.str5(.0056))
    introcs.assert_equals('0.001',  a3.str5(.0013))
    introcs.assert_equals('0.000',  a3.str5(.0004))
    introcs.assert_equals('0.001',  a3.str5(.0009999))
    introcs.assert_equals('10.00',  a3.str5(10))
    introcs.assert_equals('10.00',  a3.str5(10.0))
    introcs.assert_equals('100.0',  a3.str5(100))
    introcs.assert_equals('100.0',  a3.str5(100.0))

def test_str5_color():
    """
    Test the str5 functions for cmyk and hsv.
    """
    introcs.assert_equals('(98.45, 25.36, 72.80, 1.000)',
                          a3.str5_cmyk(introcs.CMYK(98.448, 25.362, 72.8, 1.0)))
    introcs.assert_equals('(0.007, 45.36, 100.0, 0.000)',
                          a3.str5_cmyk(introcs.CMYK(0.0067, 45.3623453301,
                           100.0, 0.0)))
    introcs.assert_equals('(98.45, 0.005, 0.300)',
                          a3.str5_hsv(introcs.HSV(98.448, 0.0054, 0.3)))
    introcs.assert_equals('(358.0, 0.057, 0.000)',
                          a3.str5_hsv(introcs.HSV(357.98, 0.0567, 0.0)))



def test_rgb_to_cmyk():
    """
    Test translation function rgb_to_cmyk
    """
    # We use a3.str5 to handle round-off error in comparisons
    rgb = introcs.RGB(255, 255, 255);
    cmyk = a3.rgb_to_cmyk(rgb);
    introcs.assert_equals('0.000', a3.str5(cmyk.cyan))
    introcs.assert_equals('0.000', a3.str5(cmyk.magenta))
    introcs.assert_equals('0.000', a3.str5(cmyk.yellow))
    introcs.assert_equals('0.000', a3.str5(cmyk.black))

    rgb = introcs.RGB(0, 0, 0);
    cmyk = a3.rgb_to_cmyk(rgb);
    introcs.assert_equals('0.000', a3.str5(cmyk.cyan))
    introcs.assert_equals('0.000', a3.str5(cmyk.magenta))
    introcs.assert_equals('0.000', a3.str5(cmyk.yellow))
    introcs.assert_equals('100.0', a3.str5(cmyk.black))

    rgb = introcs.RGB(217, 43, 164);
    cmyk = a3.rgb_to_cmyk(rgb);
    introcs.assert_equals('0.000', a3.str5(cmyk.cyan))
    introcs.assert_equals('80.18', a3.str5(cmyk.magenta))
    introcs.assert_equals('24.42', a3.str5(cmyk.yellow))
    introcs.assert_equals('14.90', a3.str5(cmyk.black))

    rgb = introcs.RGB(7, 77, 144);
    cmyk = a3.rgb_to_cmyk(rgb);
    introcs.assert_equals('95.14', a3.str5(cmyk.cyan))
    introcs.assert_equals('46.53', a3.str5(cmyk.magenta))
    introcs.assert_equals('0.000', a3.str5(cmyk.yellow))
    introcs.assert_equals('43.53', a3.str5(cmyk.black))

    rgb = introcs.RGB(25, 79, 0);
    cmyk = a3.rgb_to_cmyk(rgb);
    introcs.assert_equals('68.35', a3.str5(cmyk.cyan))
    introcs.assert_equals('0.000', a3.str5(cmyk.magenta))
    introcs.assert_equals('100.0', a3.str5(cmyk.yellow))
    introcs.assert_equals('69.02', a3.str5(cmyk.black))

    rgb = introcs.RGB(4, 2, 0);
    cmyk = a3.rgb_to_cmyk(rgb);
    introcs.assert_equals('0.000', a3.str5(cmyk.cyan))
    introcs.assert_equals('50.00', a3.str5(cmyk.magenta))
    introcs.assert_equals('100.0', a3.str5(cmyk.yellow))
    introcs.assert_equals('98.43', a3.str5(cmyk.black))


def test_cmyk_to_rgb():
    """
    Test translation function cmyk_to_rgb
    """
    cmyk = introcs.CMYK(100.0, 10.0, 1.0, 0.0);
    rgb = a3.cmyk_to_rgb(cmyk);
    introcs.assert_equals('0', str(rgb.red))
    introcs.assert_equals('230', str(rgb.green))
    introcs.assert_equals('252', str(rgb.blue))

    cmyk = introcs.CMYK(9.11, 69, 42.01, 19.20);
    rgb = a3.cmyk_to_rgb(cmyk);
    introcs.assert_equals('187', str(rgb.red))
    introcs.assert_equals('64', str(rgb.green))
    introcs.assert_equals('119', str(rgb.blue))



def test_rgb_to_hsv():
    """
    Test translation function rgb_to_hsv
    """
    rgb = introcs.RGB(100, 100, 100);
    hsv = a3.rgb_to_hsv(rgb);
    introcs.assert_equals('0.000', a3.str5(hsv.hue))
    introcs.assert_equals('0.000', a3.str5(hsv.saturation))
    introcs.assert_equals('0.392', a3.str5(hsv.value))

    rgb = introcs.RGB(242, 100, 100);
    hsv = a3.rgb_to_hsv(rgb);
    introcs.assert_equals('0.000', a3.str5(hsv.hue))
    introcs.assert_equals('0.587', a3.str5(hsv.saturation))
    introcs.assert_equals('0.949', a3.str5(hsv.value))

    rgb = introcs.RGB(242, 69, 100);
    hsv = a3.rgb_to_hsv(rgb);
    introcs.assert_equals('349.2', a3.str5(hsv.hue))
    introcs.assert_equals('0.715', a3.str5(hsv.saturation))
    introcs.assert_equals('0.949', a3.str5(hsv.value))

    rgb = introcs.RGB(100, 212, 100);
    hsv = a3.rgb_to_hsv(rgb);
    introcs.assert_equals('120.0', a3.str5(hsv.hue))
    introcs.assert_equals('0.528', a3.str5(hsv.saturation))
    introcs.assert_equals('0.831', a3.str5(hsv.value))

    rgb = introcs.RGB(100, 100, 213);
    hsv = a3.rgb_to_hsv(rgb);
    introcs.assert_equals('240.0', a3.str5(hsv.hue))
    introcs.assert_equals('0.531', a3.str5(hsv.saturation))
    introcs.assert_equals('0.835', a3.str5(hsv.value))



def test_hsv_to_rgb():
    """
    Test translation function hsv_to_rgb
    """
    hsv = introcs.HSV(9.11, 0.5, 0.5);
    rgb = a3.hsv_to_rgb(hsv);
    introcs.assert_equals('128', str(rgb.red))
    introcs.assert_equals('73', str(rgb.green))
    introcs.assert_equals('64', str(rgb.blue))

    hsv = introcs.HSV(69, 0.5, 0.5);
    rgb = a3.hsv_to_rgb(hsv);
    introcs.assert_equals('118', str(rgb.red))
    introcs.assert_equals('128', str(rgb.green))
    introcs.assert_equals('64', str(rgb.blue))

    hsv = introcs.HSV(121, 0.5, 0.5);
    rgb = a3.hsv_to_rgb(hsv);
    introcs.assert_equals('64', str(rgb.red))
    introcs.assert_equals('128', str(rgb.green))
    introcs.assert_equals('65', str(rgb.blue))

    hsv = introcs.HSV(196.9, 0.5, 0.5);
    rgb = a3.hsv_to_rgb(hsv);
    introcs.assert_equals('64', str(rgb.red))
    introcs.assert_equals('110', str(rgb.green))
    introcs.assert_equals('128', str(rgb.blue))

    hsv = introcs.HSV(246.8, 0.5, 0.5);
    rgb = a3.hsv_to_rgb(hsv);
    introcs.assert_equals('71', str(rgb.red))
    introcs.assert_equals('64', str(rgb.green))
    introcs.assert_equals('128', str(rgb.blue))

    hsv = introcs.HSV(359.0, 0.5, 0.5);
    rgb = a3.hsv_to_rgb(hsv);
    introcs.assert_equals('128', str(rgb.red))
    introcs.assert_equals('64', str(rgb.green))
    introcs.assert_equals('65', str(rgb.blue))


# Script Code
# THIS PREVENTS THE TESTS RUNNING ON IMPORT
if __name__ == '__main__':
    test_complement()
    test_round()
    test_str5()
    test_str5_color()
    test_rgb_to_cmyk()
    test_cmyk_to_rgb()
    test_rgb_to_hsv()
    test_hsv_to_rgb()
    print('Module a3 is working correctly')
