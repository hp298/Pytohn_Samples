"""
Functions for Assignment A3

This file contains the functions for the assignment.  You should replace the stubs
with your own implementations.

Jackson Bauer (jhb338) and Hermogenes Parente (hp298)
10/3/18
"""
import introcs
import math


def complement_rgb(rgb):
    """
    Returns: the complement of color rgb.

    Parameter rgb: the color to complement
    Precondition: rgb is an RGB object
    """

    return introcs.RGB(255-rgb.red, 255-rgb.green, 255-rgb.blue)


def round(number, places):
    """
    Returns: the number rounded to the given number of decimal places.

    The value returned is a float.

    This function is more stable than the built-in round.  The built-in round
    has weird behavior where round(100.55,1) is 100.5 while round(100.45,1) is
    also 100.5.  We want to ensure that anything ending in a 5 is rounded UP.

    It is possible to write this function without the second precondition on
    places. If you want to do that, we leave that as an optional challenge.

    Parameter number: the number to round to the given decimal place
    Precondition: number is an int or float

    Parameter places: the decimal place to round to
    Precondition: places is an int; 0 <= places <= 3
    """
    # To get the desired output, do the following
    #   1. Shift the number "to the left" so that the position to round to is left of
    #      the decimal place.  For example, if you are rounding 100.556 to the first
    #      decimal place, the number becomes 1005.56.  If you are rounding to the second
    #      decimal place, it becomes 10055.6.  If you are rounding 100.556 to the nearest
    #      integer, it remains 100.556.
    #   2. Add 0.5 to this number
    #   3. Convert the number to an int, cutting it off to the right of the decimal.
    #   4. Shift the number back "to the right" the same amount that you did to the left.
    #      Suppose that in step 1 you converted 100.556 to 1005.56.  In this case,
    #      divide the number by 10 to put it back.

    number = number * (10.0**places)
    number = number + 0.5
    number = int(number)
    number = float(number)
    number = number / (10.00**places)
    return number


def str5(value):
    """
    Returns: value as a string, but expand or round to be exactly 5 characters.

    The decimal point counts as one of the five characters.

    Examples:
        str5(1.3546)  is  '1.355'.
        str5(21.9954) is  '22.00'.
        str5(21.994)  is  '21.99'.
        str5(130.59)  is  '130.6'.
        str5(130.54)  is  '130.5'.
        str5(1)       is  '1.000'.

    Parameter value: the number to conver to a 5 character string.
    Precondition: value is a number (int or float), 0 <= value <= 360.
    """
    # Note:Obviously, you want to use the function round() that you just defined.
    # However, remember that the rounding takes place at a different place depending
    # on how big value is. Look at the examples in the specification.
    """
    strvalue = str(value)
    length = len(strvalue)
    decimal = index('.', strvalue)
    if length > 5:
        if decimal == 0:
            output = str(round(value, 3))
        elif decimal == 1:
            """

    if value < 10.0:
        output = str(round(value, 3))
        if len(output) == 3:
            output = output + '00'
        elif len(output) == 4:
            output = output + '0'
        #print(output) #checking
    elif value < 100.0:
        output = str(round(value, 2))
        if len(output) == 3:
            output = output + '00'
        elif len(output) == 4:
            output = output + '0'
        #print(output) #checking
    else:
        output = str(round(value, 1))
        if len(output) == 3:
            output = output + '00'
        elif len(output) == 4:
            output = output + '0'
    return output


def str5_cmyk(cmyk):
    """
    Returns: String representation of cmyk in the form "(C, M, Y, K)".

    In the output, each of C, M, Y, and K should be exactly 5 characters long.
    Hence the output of this function is not the same as str(cmyk)

    Example: if str(cmyk) is

          '(0.0,31.3725490196,31.3725490196,0.0)'

    then str5_cmyk(cmyk) is '(0.000, 31.37, 31.37, 0.000)'. Note the spaces after the
    commas. These must be there.

    Parameter cmtk: the color to convert to a string
    Precondition: cmyk is an CMYK object.
    """
    c = str5(cmyk.cyan)
    m = str5(cmyk.magenta)
    y = str5(cmyk.yellow)
    k = str5(cmyk.black)
    return '(' + c + ', ' + m + ', ' + y + ', ' + k + ')'


def str5_hsv(hsv):
    """
    Returns: String representation of hsv in the form "(H, S, V)".

    In the output, each of H, S, and V should be exactly 5 characters long.
    Hence the output of this function is not the same as str(hsv)

    Example: if str(hsv) is

          '(0.0,0.313725490196,1.0)'

    then str5_hsv(hsv) is '(0.000, 0.314, 1.000)'. Note the spaces after the
    commas. These must be there.

    Parameter hsv: the color to convert to a string
    Precondition: hsv is an HSV object.
    """
    h = str5(hsv.hue)
    s = str5(hsv.saturation)
    v = str5(hsv.value)
    return '(' + h + ', ' + s + ', ' + v + ')'


def rgb_to_cmyk(rgb):
    """
    Returns: color rgb in space CMYK, with the most black possible.

    Formulae from en.wikipedia.org/wiki/CMYK_color_model.

    Parameter rgb: the color to convert to a CMYK object
    Precondition: rgb is an RGB object
    """
    # The RGB numbers are in the range 0..255.
    # Change the RGB numbers to the range 0..1 by dividing them by 255.0.
    r = rgb.red / 255.0
    g = rgb.green / 255.0
    b = rgb.blue / 255.0
    c = 1-r
    m = 1-g
    y = 1-b
    if c == 1 and m == 1 and y == 1:
        k = 1
        c = 0
        m = 0
        y = 0
    else:
        k = min(c,m,y)
        c = (c-k)/(1-k)
        m = (m-k)/(1-k)
        y = (y-k)/(1-k)
    k = k * 100.0
    c = c * 100.0
    m = m * 100.0
    y = y * 100.0

    return introcs.CMYK(c,m,y,k)


def cmyk_to_rgb(cmyk):
    """
    Returns : color CMYK in space RGB.

    Formulae from en.wikipedia.org/wiki/CMYK_color_model.

    Parameter cmyk: the color to convert to a RGB object
    Precondition: cmyk is an CMYK object.
    """
    # The CMYK numbers are in the range 0.0..100.0.  Deal with them in the
    # same way as the RGB numbers in rgb_to_cmyk()
    c = cmyk.cyan / 100.0
    m = cmyk.magenta / 100.0
    y = cmyk.yellow / 100.0
    k = cmyk.black / 100.0
    r = (1-c)*(1-k)
    g = (1-m)*(1-k)
    b = (1-y)*(1-k)
    r = r*255.0
    g = g*255.0
    b = b*255.0
    r = int(round(r,0))
    g = int(round(g,0))
    b = int(round(b,0))

    return introcs.RGB(r,g,b)


def rgb_to_hsv(rgb):
    """
    Return: color rgb in HSV color space.

    Formulae from wikipedia.org/wiki/HSV_color_space.

    Parameter rgb: the color to convert to a HSV object
    Precondition: rgb is an RGB object
    """
    # The RGB numbers are in the range 0..255.
    # Change them to range 0..1 by dividing them by 255.0.
    r = rgb.red / 255.0
    g = rgb.green / 255.0
    b = rgb.blue / 255.0
    MAX = max(r,g,b)
    MIN = min(r,g,b)
    if MAX == MIN:
        h = 0
    elif MAX == r and g >= b:
        h = 60.0*(g-b)/(MAX-MIN)
    elif MAX == r and g < b:
        h = 60.0*(g-b)/(MAX-MIN) + 360.0
    elif MAX == g:
        h = 60.0*(b-r)/(MAX-MIN) + 120.0
    elif MAX == b:
        h = 60.0*(r-g)/(MAX-MIN) + 240.0

    if MAX == 0:
        s = 0
    else:
        s = 1-(MIN/MAX)

    v = MAX

    return introcs.HSV(h,s,v)


def hsv_to_rgb(hsv):
    """
    Returns: color in RGB color space.

    Formulae from http://en.wikipedia.org/wiki/HSV_color_space.

    Parameter hsv: the color to convert to a RGB object
    Precondition: hsv is an HSV object.
    """

    hi = math.floor(hsv.hue/60)
    f = (hsv.hue/60) - hi
    p = hsv.value*(1-hsv.saturation)
    q = hsv.value*(1-(f*hsv.saturation))
    t = hsv.value*(1-((1-f)*hsv.saturation))

    if hi == 0:
        r = hsv.value
        g = t
        b = p
    elif hi == 1:
        r = q
        g = hsv.value
        b = p
    elif hi == 2:
        r = p
        g = hsv.value
        b = t
    elif hi == 3:
        r = p
        g = q
        b = hsv.value
    elif hi == 4:
        r = t
        g = p
        b = hsv.value
    elif hi == 5:
        r = hsv.value
        g = p
        b = q
    r = r*255.0
    g = g*255.0
    b = b*255.0
    r = int(round(r,0))
    g = int(round(g,0))
    b = int(round(b,0))

    return introcs.RGB(r,g,b)
