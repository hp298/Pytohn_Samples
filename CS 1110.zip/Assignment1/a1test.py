"""
Unit test for module a1

When run as a script, this module invokes several procedures that
test the various functions in the module a1.

Author: Hermogenes Parente (hp298) & Jackson Bauer (jhb338)
Date:   September 14, 2018
"""
import introcs
import a1


def testA():
    """
    Test procedure for Part A
    """

    s = ' '
    introcs.assert_equals('', a1.before_space(s))
    introcs.assert_equals('', a1.after_space(s))

    s = "0.863569 Euros"
    introcs.assert_equals('0.863569', a1.before_space(s))
    introcs.assert_equals('Euros', a1.after_space(s))

    s = "    0.863569 Euros    "
    introcs.assert_equals('', a1.before_space(s))
    introcs.assert_equals('   0.863569 Euros    ', a1.after_space(s))

    s = "0.863569    Euros"
    introcs.assert_equals('0.863569', a1.before_space(s))
    introcs.assert_equals('   Euros', a1.after_space(s))

    s = " 0.863569 Euros"
    introcs.assert_equals('', a1.before_space(s))
    introcs.assert_equals('0.863569 Euros', a1.after_space(s))

    s = "0.863569Euros "
    introcs.assert_equals('0.863569Euros', a1.before_space(s))
    introcs.assert_equals('', a1.after_space(s))

    s = "0.863569 Euros and dollars"
    introcs.assert_equals('0.863569', a1.before_space(s))
    introcs.assert_equals('Euros and dollars', a1.after_space(s))


def testB():
    """
    Test procedure for Part B
    """
    s = 'A "B C" D'
    introcs.assert_equals('B C', a1.first_inside_quotes(s))
    s ='A "B C" D "E F" G'
    introcs.assert_equals('B C', a1.first_inside_quotes(s))

    s = '{ "src" : "2 United States Dollars", "dst" ' + \
    ': "1.727138 Euros", "valid" : true, "error" : "" }'
    introcs.assert_equals('2 United States Dollars', a1.get_src(s))
    introcs.assert_equals('1.727138 Euros', a1.get_dst(s))
    introcs.assert_equals( False, a1.has_error(s))

    s = '{ "src"      :        "2 United States Dollars"       , "dst"    ' + \
    '   :       "1.727138 Euros",       "valid"       :         true,     ' + \
    '    "error"       :       "" }'
    introcs.assert_equals('2 United States Dollars', a1.get_src(s))
    introcs.assert_equals('1.727138 Euros', a1.get_dst(s))
    introcs.assert_equals( False, a1.has_error(s))


    s = '{"src":"2 United States Dollars","dst":"1.727138 Euros","valid":' + \
    'true,"error":""}'
    introcs.assert_equals('2 United States Dollars', a1.get_src(s))
    introcs.assert_equals('1.727138 Euros', a1.get_dst(s))
    introcs.assert_equals( False, a1.has_error(s))

    s = '{ "src" : "", "dst" : "", "valid" : false, "error" : "Source' + \
    'currency code is invalid." }'
    introcs.assert_equals('', a1.get_src(s))
    introcs.assert_equals('', a1.get_dst(s))
    introcs.assert_equals( True, a1.has_error(s))


def testC():
    """
    Test procedure for Part C
    """

    introcs.assert_equals('{ "src" : "2.5 United States Dollars", "dst" '+\
    ': "2.1589225 Euros", "valid" : true, "error" : "" }',
    a1.currency_response('USD','EUR',2.5))
    introcs.assert_equals('{ "src" : "2.5 United States Dollars", "dst" '+\
    ': "2.1589225 Euros", "valid" : true, "error" : "" }',
    a1.currency_response('usd','eur',2.5))
    introcs.assert_equals('{ "src" : "2.5 United States Dollars", "dst" '+\
    ': "2.1589225 Euros", "valid" : true, "error" : "" }',
    a1.currency_response('UsD','eUr',2.5))
    introcs.assert_equals('{ "src" : "3 Bitcoins", "dst" '+\
    ': "30406.771618779 Singapore Dollars", "valid" : true, "error" : "" }',
    a1.currency_response('btc','sgd',3))
    introcs.assert_equals('{ "src" : "9.000001 São Tomé and Príncipe Dobras '+\
    '(pre-2018)", "dst" : "0.0034582649633479 Macanese Patacas", "valid" '+\
    ': true, "error" : "" }', a1.currency_response('std','mop',9.000001))
    introcs.assert_equals('{ "src" : "2.5 United States Dollars", "dst" '+\
    ': "2.1589225 Euros", "valid" : true, "error" : "" }',
    a1.currency_response(' USD ',' EUR ',2.5))
    introcs.assert_equals('{ "src" : "", "dst" : "", "valid" : false, "error"'+\
    ' : "Source currency code is invalid." }',
    a1.currency_response(' U S D ',' E U R ',2.5))
    introcs.assert_equals('{ "src" : "", "dst" : "", "valid" : false, "error"'+\
    ' : "Source currency code is invalid." }',
    a1.currency_response('AAA','EUR',2.5))
    introcs.assert_equals('{ "src" : "", "dst" : "", "valid" : false, "error"'+\
    ' : "Exchange currency code is invalid." }',
    a1.currency_response('USD','AAA',2.5))


def testD():
    """
    Test procedure for Part D
    """

    introcs.assert_equals(True, a1.iscurrency('usd'))
    introcs.assert_equals(True, a1.iscurrency('btc'))
    introcs.assert_equals(True, a1.iscurrency('eur'))
    introcs.assert_equals(False, a1.iscurrency('aaa'))
    introcs.assert_equals(False, a1.iscurrency('United People of Godzilla'))

    introcs.assert_floats_equal(2.1589225, a1.exchange('usd','eur',2.5))
    introcs.assert_floats_equal(30406.771618779, a1.exchange('btc','sgd',3))
    introcs.assert_floats_equal(0.0034582649633479, a1.exchange('std','mop',9.000001))


testA()
testB()
testC()
testD()
print("Module a1 passed all tests")
