"""
User interface for module currency

When run as a script, this module prompts the user for two currencies and amount.
It prints out the result of converting the first currency to the second.

Author: Hermogenes Parente (hp298) & Jackson Bauer (jhb338)
Date:   September 14, 2018 """

import a1

original = input('3-letter code for original currency: ')
new = input('3-letter code for the new currency: ')
amount = input('Amount of the original currency: ')
exchange = a1.exchange(original, new, amount)
print('You can exchange ' + str(amount) + ' ' + original.upper() + ' for ' +
 str(exchange) + ' ' + new.upper() + '.')
